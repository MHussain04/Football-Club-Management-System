package application;

import java.io.IOException;
import java.sql.SQLException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class PlayerStatistics {
	
	private int player_id,appearances,goals,assists,trophies;
	
	//private String name;
	
	private String season;
	
	private String behavior_records;

	public PlayerStatistics() {
		// TODO Auto-generated constructor stub
	}
	
	public PlayerStatistics(int appearances,int goals, int assists, int trophies)
	
	{
		
		this.appearances = appearances;
		
		this.goals = goals;
		
		this.assists = assists;
		
		this.trophies = trophies;
	}

	public void DisplayPlayerStats(int id, String name, String season,Stage current_stage) throws IOException, ClassNotFoundException, SQLException
	
	{
		this.season = season;
		
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/UI_Package/Display_player_stats.fxml"));
		
        BorderPane root = loader.load();
        
        Display_player_stats controller = loader.getController();
        
        controller.setplayerinfo(id,name,this.season);
        
        controller.display_labels();
        
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
        
        current_stage.close();
	}

	public int getGoals() {
		return goals;
	}

	public void setGoals(int goals) {
		this.goals = goals;
	}

	public int getAssists() {
		return assists;
	}

	public void setAssists(int assists) {
		this.assists = assists;
	}

	public int getTrophies() {
		return trophies;
	}

	public void setTrophies(int trophies) {
		this.trophies = trophies;
	}

	public int getAppearances() {
		return appearances;
	}

	public void setAppearances(int appearances) {
		this.appearances = appearances;
	}

	public String getBehavior_records() {
		return behavior_records;
	}

	public void setBehavior_records(String behavior_records) {
		this.behavior_records = behavior_records;
	}
}
