package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import dbPackage.dbHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class Tactics_Module {

	
	private String defensive_style;
	
	private String formation;
	
	private String offensive_style;
	
	private String chance_creation;
	
	private int match_id;
	
	private int defensive_width;
	
	private int defensive_depth;
	
	private int attacking_width;
	
	public static int reference;
	
	public Tactics_Module() {
		// TODO Auto-generated constructor stub
	}

	public Tactics_Module(int m_id,String f,String d_style,int d_width,int d_depth,String o_style,String c_creation,int o_width)
	
	{
		
		this.match_id = m_id;
		
		this.formation = f;
		
		this.defensive_style = d_style;
		
		this.defensive_width = d_width;
		
		this.defensive_depth = d_depth;
		
		this.offensive_style = o_style;
		
		this.chance_creation = c_creation;
		
		this.attacking_width = o_width;
	}
	
	public void ReviewPerformanceData(Stage current_stage) throws IOException
	
	{
		
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/UI_Package/manage_tactics.fxml"));
		
		String default_formation = "3-2-4-1";
		
        BorderPane root = loader.load();
        
        manage_tacticsController controller = loader.getController();
        
        controller.set_formation(default_formation);
        
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
        
        current_stage.close();
      
	}
	
	public void insert_tactics(Stage stage) throws ClassNotFoundException, SQLException
	
	{
		
		boolean flag = dbHandler.getInstance().check_match_tactics(this.match_id);
		
		System.out.print(this.match_id);

        
        if(flag == false)
        	
       {
        
        	
        	dbHandler.getInstance().insert_tactics(match_id, formation, defensive_style, defensive_width, defensive_depth, offensive_style, chance_creation, attacking_width);
	        stage.close();
        
	    }

        
        else if(flag == true)
        	
        {
        	
       //  System.out.print(flag);
       //  System.out.print(formation);
       //  System.out.print(defensive_style);
     	 dbHandler.getInstance().update_match_tactics(match_id, formation, defensive_style, defensive_width, defensive_depth, offensive_style, chance_creation, attacking_width);		        
     	 stage.close();
     		        	 
     		        	
        }
        
        
	}
	
	
}