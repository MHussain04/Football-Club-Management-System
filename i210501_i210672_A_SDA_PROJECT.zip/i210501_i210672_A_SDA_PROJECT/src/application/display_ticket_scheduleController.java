package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dbPackage.dbHandler;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;

import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.scene.control.TableColumn;

public class display_ticket_scheduleController {
	@FXML
	private TableView<Match> ticket_data;
	@FXML
	private TableColumn<Match,Integer> col_id;
	@FXML
	private TableColumn<Match,String> col_vs;
	@FXML
	private TableColumn<Match,Date> col_date;
	@FXML
	private TableColumn<Match,String> col_location;
	
	@FXML 
	
	private TableColumn<Match,Button> ticket_button;
	
	@FXML 
	
	private Button return_button;
	
	@FXML
	
	private Button check_outbutton;
	
	public int total_price;
	
	public static int balance;
	
	static public int fan_id;
	
	ObservableList<Match> t_data;
	
	public static String status;
	
	
	public void set_status(String status)
	
	{
		
		display_ticket_scheduleController.status =  status;
	}
	
	

	public void set_fanid(int id)
	
	{
		
		display_ticket_scheduleController.fan_id = id;
		
		
	}
	
	
	public void addtoCart_ticket(Match m) throws ClassNotFoundException, SQLException
	 
	 {
		 
		 // System.out.print("Tired");
		 
		// System.out.print(m.match_id);
		 
		 int merch_id = 0;
		
		 int max_item_id = dbHandler.getInstance().get_max_item_id(display_ticket_scheduleController.fan_id);
		 
		 int price = dbHandler.getInstance().get_individual_item_price(m.match_id,merch_id);
		 
		// System.out.print(price);
		
		 total_price = dbHandler.getInstance().get_total_price_of_cart(price);
		 
		// System.out.print(total_price);
    
		 balance = dbHandler.getInstance().get_fan_balance(display_ticket_scheduleController.fan_id);
        	
        	
         boolean flag = checking_balance();
        	
        	if(flag == true)
        		
         {
        	
        	dbHandler.getInstance().insert_item_into_cart(max_item_id,m.match_id,merch_id,display_ticket_scheduleController.fan_id,total_price);
        		
         }
        	
        	else
        		
        	{
        		
        		Alert alert = new Alert(AlertType.ERROR);
             	 
   		        alert.setTitle("Error");
   		     
   		        alert.setHeaderText(null);
   		     
   		        alert.setContentText("You have insufficient balance to add this item into your cart.");
   		     
   		        alert.showAndWait();
        	}
        	
        	
	 }
	
	
	
	public void initialize() {
		// TODO Auto-generated method stub

		col_id.setCellValueFactory(new PropertyValueFactory<Match,Integer>("match_id"));
		
		col_vs.setCellValueFactory(new PropertyValueFactory<Match,String>("vs"));
		
		col_date.setCellValueFactory(new PropertyValueFactory<Match,Date>("match_date"));
		
		col_location.setCellValueFactory(new PropertyValueFactory<Match,String>("location"));
		
		ticket_button.setCellValueFactory(new PropertyValueFactory<Match,Button>("ticket_button"));
		
		try
		
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
			
			t_data = FXCollections.observableArrayList();
			
			try
			
			{
				
				String match_query = "select match_id,vs,match_date,location from match_ where match_status = ? ";
	        	
	        	try (PreparedStatement managerStatement = con.prepareStatement(match_query))
				
				{
                    
					managerStatement.setString(1, status); 
					
					 try (ResultSet resultSet = managerStatement.executeQuery()) 
					 
					 {
						 
		                    while (resultSet.next()) 
		                    
		                    {
		                    	
	
		                    	t_data.add(new Match(resultSet.getInt("match_id"),resultSet.getString("vs"),resultSet.getDate("match_date"),resultSet.getString("location")));
		                    
		                    	
		                    }
		                    
			         }
			
					 catch (SQLException e) 
			
					 {
				// TODO Auto-generated catch block
						 e.printStackTrace();
					 }
			
		         }
		
			}
			
			
					catch (SQLException e) 
		
					{
			// TODO Auto-generated catch block
						e.printStackTrace();
					}

       }
	
	
	    catch (SQLException e1) 
		
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		
		catch (ClassNotFoundException e1) 
		
		{
		// TODO Auto-generated catch block
			e1.printStackTrace();
	     }


      ticket_data.setItems(t_data);
      
      
		
	}
	
	
	

	
	
	
	@FXML
	public void returnbtnClicked(ActionEvent event) throws IOException, ClassNotFoundException, SQLException
	
	{
		
		 FXMLLoader loader = new FXMLLoader(getClass().getResource("/UI_Package/select_transaction_type.fxml"));
    	 
    	 
         BorderPane root = loader.load();
         
         select_transaction_type controller = loader.getController();
         
         controller.display_balance();
         
         Scene scene = new Scene(root);
         Stage stage = new Stage();
         stage.setScene(scene);
         stage.show();

         // Close the current login window
         
         Stage currentStage = (Stage) return_button.getScene().getWindow();
         currentStage.close();
	}
	
	@FXML
	
	public void check_outbtnClicked(ActionEvent event) throws IOException, ClassNotFoundException, SQLException
	
	{
		
		int ticket_reference = 2;

		FXMLLoader loader = new FXMLLoader(getClass().getResource("/UI_Package/checkout.fxml"));

	    BorderPane root = loader.load();
	    
	    checkoutController controller = loader.getController();
	    
	    controller.set_fanid(display_ticket_scheduleController.fan_id,ticket_reference);
	    
	    controller.set_balance(balance);
	    
	    controller.displaycartitems(display_ticket_scheduleController.fan_id);
	    
	    
	    
	    Scene scene = new Scene(root);
	    Stage stage1 = new Stage();
	    stage1.setScene(scene);
	    stage1.show();

	    Stage currentStage = (Stage) check_outbutton.getScene().getWindow();
	    
	    currentStage.close();
		
	}
	
	
	public void set_balance(int b)
	
	{
		
		display_ticket_scheduleController.balance = b;
		
		// System.out.print(balance);
		
	}
	
	public boolean checking_balance() throws ClassNotFoundException, SQLException
	
	{
		
	   boolean flag = false;
	   
	   if(balance < total_price)
		   
	   {
		 
		   
		   flag = false;
	   }
	   
	   else
		   
	   {
		   
		   flag = true;
		   
		   
	   }
	   
	   return flag;
	}
	
	
}
