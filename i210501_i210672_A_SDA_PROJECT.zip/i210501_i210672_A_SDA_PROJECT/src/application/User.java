package application;

import java.sql.SQLException;

public abstract class User {
	
	public String username;
	
	public String Password;

	public String Role;
	
	public static Integer id;
	
	public User() 
	
	{
		// TODO Auto-generated constructor stub
	}

	public void setName(String name)
	
	{
		
		this.username=name;
	}
	
	public void setPassword(String password)
	
	{
		this.Password = password;
		
	}
	
	public void setRole(String role)
	
	{
		
		this.Role = role;
	}

	public Integer get_Id() {
		return id;
	}

	public void set_id(Integer id) {
		// TODO Auto-generated method stub
		User.id = id;

	}
}
