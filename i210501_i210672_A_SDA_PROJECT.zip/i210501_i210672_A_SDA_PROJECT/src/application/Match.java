package application;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import javafx.scene.control.Button;

public class Match {
	
	public int match_id;
	
	private String vs;
	
	private Date match_date;
	
	private String location;
	
	private String result;
	
	private Button ticket_button;
	
	public static int reference;

	public Match() {
		// TODO Auto-generated constructor stub
	}

	public Match(int match_id,String vs,Date match_date,String location,String result)
	
	{
		this.match_id = match_id;
		
		this.vs = vs;
		
		this.match_date = match_date;
		
		this.location = location;
		
		this.result = result;
		
	}
	
	
	public Match(int match_id,String vs,Date match_date,String location)

	{
		this.match_id = match_id;
		
		this.vs = vs;
		
		this.match_date = match_date;
		
		this.location = location;
		
		this.ticket_button = new Button("Add to Cart");
		
		display_ticket_scheduleController controller = new display_ticket_scheduleController();
		
		this.ticket_button.setOnAction(event -> {
			try {
				controller.addtoCart_ticket(this);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		
		
	}

	
	public void Display_Match_Schedule(Stage current_stage,int reference) throws IOException
	
	{
		
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/UI_Package/select_match_status.fxml"));
		BorderPane root = loader.load();
		
		select_match_status controller = loader.getController();
		
		controller.set_reference(reference);
		
	    Scene scene = new Scene(root);
	    Stage stage = new Stage();
	    stage.setScene(scene);
	    stage.show();

        // Close the current window
	    
       current_stage.close();
       
	}

	
	public void AccessPerformanceData(Stage current_stage) throws IOException
	
	{
		
		
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/UI_Package/monitor_team_performance_data.fxml"));
        BorderPane root = loader.load();
        
        monitor_team_performance_dataController controller = loader.getController();
        
        controller.set_reference(reference);
        
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
        
        current_stage.close();
        
	}
	
	
	public void set_reference(int r)
	
	{
		
		Match.reference = r;
	}

	public int getMatch_id() {
		return match_id;
	}

	public void setMatch_id(int match_id) {
		this.match_id = match_id;
	}

	public String getVs() {
		return vs;
	}

	public void setVs(String vs) {
		this.vs = vs;
	}

	public Date getMatch_date() {
		return match_date;
	}

	public void setMatch_date(Date match_date) {
		this.match_date = match_date;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Button getTicket_button() {
		return ticket_button;
	}

	public void setTicket_button(Button ticket_button) {
		this.ticket_button = ticket_button;
	}
}
