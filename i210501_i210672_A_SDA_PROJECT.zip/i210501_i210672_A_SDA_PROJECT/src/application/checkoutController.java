package application;

import java.awt.event.ActionEvent;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dbPackage.dbHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;

import javafx.scene.control.TextArea;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class checkoutController {
	@FXML
	private TextArea text_area;
	@FXML
	private Label Total_price;
	
	@FXML 
	
	private Button confirm_purchase;
	
	@FXML
	
	private Button return_button;
	
	@FXML 
	
	private Button remove_from_cart;
	
	@FXML
	
	private VBox itemsVBox;

	static public int fan_id;
	
	public int ticket_id;
	
	public int item_id;
	
	public int merch_id;

	public int total_price;

	public int balance;
	
	public int reference;



 public void set_fanid(int id,int reference)


{
	
	checkoutController.fan_id = id;
	
	this.reference = reference;
	
}
 
public void displaycartitems(int fan_id) throws ClassNotFoundException, SQLException

{
	
	StringBuilder itemsText = new StringBuilder();
	
	Class.forName("com.mysql.cj.jdbc.Driver");
	
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
    
    total_price = dbHandler.getInstance().get_checkout_price(fan_id);
    
    String query = "SELECT item_id, ticket_id, merch_id FROM cart WHERE fan_id = ?";
    
    PreparedStatement cartStatement = con.prepareStatement(query);
	
	
    	
    	cartStatement.setInt(1,checkoutController.fan_id);
    	
    	ResultSet resultSet = cartStatement.executeQuery();
    	
    	while (resultSet.next()) 
            
        {
     	
     	item_id = resultSet.getInt("item_id");
     	
     	ticket_id = resultSet.getInt("ticket_id");
     	
     	merch_id = resultSet.getInt("merch_id");
     	
     	int price = dbHandler.getInstance().get_individual_item_price(ticket_id, merch_id);
         
        String item_description = dbHandler.getInstance().get_item_description(ticket_id, merch_id);
        
         
        itemsText.append("Item id: ").append(item_id).append("\n").append(item_description).append("\n").append("Price: ").append(price).append("\n");
     	
         
        }
    			

    itemsText.append("Total Price: ").append(total_price);

    text_area.setText(itemsText.toString());
    
    text_area.setEditable(false);
    

  }
	
	
	
	@FXML
	
	public void purchasebtnClicked() throws ClassNotFoundException, SQLException, IOException
	
  {
		
		dbHandler.getInstance().update_fan_balance(fan_id, balance, total_price);
		
	       // Close the current login window
        
        dbHandler.getInstance().confirm_purchase(fan_id);
        
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/UI_Package/Fan.fxml"));
        BorderPane root = loader.load();
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();

        // Close the current login window
        Stage currentStage = (Stage) confirm_purchase.getScene().getWindow();
    
        currentStage.close();
        
        
        
  }
        
	   

	
	@FXML
	
	public void returnbtnClicked() throws IOException
	
	{
		
	if(this.reference == 1)
		
	{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/UI_Package/display_merchandise.fxml"));

	    BorderPane root = loader.load();
		
	    Scene scene = new Scene(root);
	    Stage stage1 = new Stage();
	    stage1.setScene(scene);
	    stage1.show();


	}
	
	else if(reference == 2)
		
	{
		
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/UI_Package/display_ticket_schedule.fxml"));

	    BorderPane root = loader.load();
	    
	    Scene scene = new Scene(root);
	    Stage stage1 = new Stage();
	    stage1.setScene(scene);
	    stage1.show();
		
		
	}
	
    Stage currentStage = (Stage) return_button.getScene().getWindow();
    
    currentStage.close();
		
	}
	

public void set_balance(int b)
	
	{
		
		this.balance = b;
		
		// System.out.print(balance);
		
	}
}