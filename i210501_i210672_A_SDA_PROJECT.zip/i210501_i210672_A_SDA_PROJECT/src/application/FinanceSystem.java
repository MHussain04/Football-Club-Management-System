package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dbPackage.dbHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class FinanceSystem {
	
	private int amount;
	
	private int club_budget;
	
	Stage current_stage;
	
	private int reference;

	public FinanceSystem() {
		// TODO Auto-generated constructor stub
	}

	
	public void RequestTransaction(int a,Stage stage,int r) throws ClassNotFoundException, SQLException, IOException
	
	{
		this.reference = r;
		
		this.amount = a;
		
		this.club_budget = dbHandler.getInstance().get_club_budget();
		
		this.current_stage = stage;
		
		ProcessandUpdate();
		
		
	}
	
	public void request(int a,int r) throws ClassNotFoundException, SQLException, IOException
	
	{
		
		this.reference = r;
		
		this.amount = a;
		
		this.club_budget = dbHandler.getInstance().get_club_budget();
	
		ProcessandUpdate();
	}

	
	public void ProcessandUpdate() throws ClassNotFoundException, SQLException, IOException
	
	{
		if(reference == 1)
			
		{
			
		club_budget = club_budget - amount;
		
		}
		
		else if(reference == 2 || reference == 3)
			
		{
			
			club_budget = club_budget + amount;
		}
		
		

		dbHandler.getInstance().process_expenditure_transaction(club_budget);
		
	
        // Close the current login window
        
   /*    if(reference == 1 || reference == 2)
    	   
       {
    	   
    	   
       
       this.current_stage.close();
       
       
       }	
       
   */
		        	
	}
	
	
}
