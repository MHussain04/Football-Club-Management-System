package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dbPackage.dbHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class Expenditures {

	private int expenditure_id;
	
	private int amount;
	
	private Date date;
	
	private String description;
	
	private Button updatebutton;
	
	private int reference;
	
	public Expenditures() {
		// TODO Auto-generated constructor stub
	}
	
	
	public Expenditures(int id,int amount,String description,Date date,int r)
	
	{
		
		this.expenditure_id = id;
		
		this.amount = amount;
		
		this.description = description;
		
		this.date = date;
		
		this.reference = r;
		
		if(reference == 1)
			
		{
		
		
		this.updatebutton = new Button("Update Expenditure");
		
		update_expendituresListController controller = new update_expendituresListController();
		
		this.updatebutton.setOnAction(event -> {
			try {
				
				controller.click_update_button(this);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		
		
	   }
		
		
		else if(reference == 3)
			
		{
			
			this.updatebutton = new Button("Delete Expenditure");
			
			delete_expendituresListController controller = new delete_expendituresListController();
			
			this.updatebutton.setOnAction(event -> {
				
				try {
					
					controller.click_delete_button(this);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});
			
			
		}
		
		
	}
	
	
	public void EnterDetails(int amount,String description,Date date,Stage current_stage) throws ClassNotFoundException, SQLException, IOException
	
	{
		
		this.amount = amount;
		
		this.date = date;
		
		this.description = description;
		
		int max_id = dbHandler.getInstance().get_max_expenditure_id();
		
		dbHandler.getInstance().insert_into_expenditures(max_id,this.amount,this.date,this.description,current_stage);
		
		
		
		
	}
	



	public int getExpenditure_id() {
		return expenditure_id;
	}


	public void setExpenditure_id(int expenditure_id) {
		this.expenditure_id = expenditure_id;
	}


	public int getAmount() {
		return amount;
	}


	public void setAmount(int amount) {
		this.amount = amount;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public Button getUpdatebutton() {
		return updatebutton;
	}


	public void setUpdatebutton(Button updatebutton) {
		this.updatebutton = updatebutton;
	}

}
