package dbPackage;

import application.enter_info;
import application.select_transaction_type;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import application.Admin;
import application.FinanceSystem;
import application.Match;
import application.Player;
import application.PlayerStatistics;
import application.User;
import application.checkoutController;
import application.display_ticket_scheduleController;
import application.update_fan_info;
import application.update_manager_info;
import application.update_player_info;
import application.update_staff_info;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class dbHandler {
	
	private static dbHandler uniqueInstance = null;

	
	private dbHandler() {
		// TODO Auto-generated constructor stub
	}
	
	public static dbHandler getInstance()
	
	{
		
		if(uniqueInstance == null)
			
		{
			uniqueInstance = new dbHandler();
		}
		
		return uniqueInstance;
	}

	
	
	public void insert_user(int user_id,String name,String password,String role) throws ClassNotFoundException, SQLException
	
	{
		
		 Class.forName("com.mysql.cj.jdbc.Driver");
         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
         
         String insertQuery = "INSERT INTO user(user_id, username, password, role) VALUES (?, ?, ?, ?)";
         try (PreparedStatement pstmt = con.prepareStatement(insertQuery)) 
         
         {
             pstmt.setInt(1, user_id);
             pstmt.setString(2, name);
             pstmt.setString(3, password);
             pstmt.setString(4, role);
             pstmt.executeUpdate();

         }
	}
	
	public int get_max_user_id(String name,String password,String role) throws ClassNotFoundException, SQLException
	
	{
		
		 int lastUserId = 0;
         Class.forName("com.mysql.cj.jdbc.Driver");
         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
         
         String query = "SELECT MAX(user_id) FROM user";
         try (Statement stmt = con.createStatement();
              ResultSet rs = stmt.executeQuery(query)) 
         
         {
             if (rs.next()) 
             
             {
                 lastUserId = rs.getInt(1);
                 lastUserId+=1;
                 
                 Admin admin = new Admin();
                 
                 admin.Add_User(lastUserId,name,password,role);
                 
                 
             }
             
             
         }
         
         return lastUserId;
         
	}
	
	public void insert_Player(int max_id,String position,String shirt_number,Date DOB,Date CSD,Date CED) throws ClassNotFoundException, SQLException
	
	{
		

		 Class.forName("com.mysql.cj.jdbc.Driver");
         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
		
	    String playerInsertSQL = "INSERT INTO Player (player_id, position, dob, shirt_number, contract_start_date, contract_end_date) VALUES (?, ?, ?, ?, ?,?)";
        
		try (PreparedStatement playerStatement = con.prepareStatement(playerInsertSQL))
		
		{
			 	playerStatement.setInt(1, max_id); // Assuming player_id is the same as user_id
                playerStatement.setString(2, position); // Replace with your actual text field
                playerStatement.setDate(3, DOB); // Replace with your actual text field
                playerStatement.setString(4, shirt_number); // Replace with your actual text field
                playerStatement.setDate(5, CSD); // Replace with your actual text field
                playerStatement.setDate(6, CED);
			
                playerStatement.executeUpdate();
                
                Alert alert = new Alert(AlertType.INFORMATION);
		        alert.setTitle("Success");
		        alert.setHeaderText(null);
		        alert.setContentText("Player inserted successfully.");

			     // Show the alert
			     alert.showAndWait();
		}
	    
	}
	
	
	public void InsertManager(int max_id,int salary) throws ClassNotFoundException, SQLException
	
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
		
		
		 	String managerInsertSQL = "INSERT INTO Club_Manager (manager_id,salary) VALUES (?,?)";
         
			try (PreparedStatement managerStatement = con.prepareStatement(managerInsertSQL))
			
			{
         
				managerStatement.setInt(1, max_id);
				
				managerStatement.setInt(2, salary);
				
				managerStatement.executeUpdate();
				
				    Alert alert = new Alert(AlertType.INFORMATION);
			        alert.setTitle("Success");
			        alert.setHeaderText(null);
			        alert.setContentText("Manager inserted successfully.");
				     // Show the alert
				    alert.showAndWait();

				
			}
         
	}
	
	public void Insert_Staff(int max_id,String post,int salary) throws ClassNotFoundException, SQLException
	
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
		
		String staffInsertSQL = "INSERT INTO Coaching_Staff (staff_id, post, salary) VALUES (?, ?, ?)";
         
			try (PreparedStatement staffStatement = con.prepareStatement(staffInsertSQL))
			
			{
				
           
				
			    
			    staffStatement.setInt(1, max_id); 
			    
			    staffStatement.setString(2,post);
			    
			    staffStatement.setInt(3, salary);
            
				staffStatement.executeUpdate();
				
				 Alert alert = new Alert(AlertType.INFORMATION);
			     alert.setTitle("Success");
			     alert.setHeaderText(null);
			     alert.setContentText("Staff inserted successfully.");
	
			     // Show the alert
			     alert.showAndWait();
				
			}
         
	}
	
	public void insert_Fan(int max_id,int balance) throws ClassNotFoundException, SQLException
	
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
		
		 String fanInsertSQL = "INSERT INTO fan (fan_id,balance) VALUES (?,?)";
         
			try (PreparedStatement fanStatement = con.prepareStatement(fanInsertSQL))
			
			{
				
				fanStatement.setInt(1,max_id);
				fanStatement.setInt(2, balance);
				fanStatement.executeUpdate();
				
				 Alert alert = new Alert(AlertType.INFORMATION);
			     alert.setTitle("Success");
			     alert.setHeaderText(null);
			     alert.setContentText("Fan inserted successfully.");
			     

			     // Show the alert
			     alert.showAndWait();
			     
			     
			}
         
	}
	
	public void checking_user_status(String username,String password,Stage stage) throws ClassNotFoundException, SQLException, IOException
	
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");

        String user_query = "SELECT * FROM user WHERE username=? AND password=?";
        PreparedStatement user_pstmt = con.prepareStatement(user_query);
        user_pstmt.setString(1, username);
        user_pstmt.setString(2, password);
        
        ResultSet user_result = user_pstmt.executeQuery();

        if (user_result.next()) 
        
        {
        	
        	 Alert alert = new Alert(AlertType.INFORMATION);
        	 
		     alert.setTitle("Success");
		     
		     alert.setHeaderText(null);
		     
		     alert.setContentText("User exists.");
		     
			 alert.showAndWait();
			 
			 String role = user_result.getString("Role");
	        	 
		     int user_id = user_result.getInt("user_id");
		     
		     enter_info manage = new enter_info();
		     
		     manage.navigating_to_interface(role, user_id, stage);
		    
		     
			 
	   }
   
    
        	else
    	
        	{
        		
        		Alert alert = new Alert(AlertType.ERROR);
    	 
        		alert.setTitle("Error");
		     
        		alert.setHeaderText(null);
		     
        		alert.setContentText("No such Username or Password");
	
        		alert.showAndWait();
        	}
        
	}
	
	
	public static void update_manager_name(String username,int user_id) throws ClassNotFoundException, SQLException
	
	
	{
		
			Class.forName("com.mysql.cj.jdbc.Driver");
			
        	Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        	String updateSQL = "UPDATE user SET username = ? WHERE user_id = ?";
        
			PreparedStatement updateStatement = con.prepareStatement(updateSQL);
			
			 updateStatement.setString(1, username);
		     updateStatement.setInt(2, user_id);
		     
		     int rowsUpdated = updateStatement.executeUpdate();
		     
		        if (rowsUpdated > 0)
		        
		        {
		        	
		             Alert alert = new Alert(AlertType.INFORMATION);
		        	 
				     alert.setTitle("Success");
				     
				     alert.setHeaderText(null);
				     
				     alert.setContentText("Manager Username updated successfully.");
				        
				  
					     // Show the alert
					 alert.showAndWait();
					 
					 
		        }
		        
		        
	}
	
	
	public static void update_manager_password(String password,int user_id) throws SQLException, ClassNotFoundException
	
	{
		
			Class.forName("com.mysql.cj.jdbc.Driver");
			
        	Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        	String updateSQL = "UPDATE user SET password = ? WHERE user_id = ?";
   
			PreparedStatement updateStatement = con.prepareStatement(updateSQL);
			
			 updateStatement.setString(1, password);
		     updateStatement.setInt(2, user_id);
		     
		     int rowsUpdated = updateStatement.executeUpdate();
		     
		        if (rowsUpdated > 0)
		        
		        {
		        	  	 Alert alert = new Alert(AlertType.INFORMATION);
			        	 
					     alert.setTitle("Success");
					     
					     alert.setHeaderText(null);
					     
					     alert.setContentText("Manager Password updated successfully.");
					        
	
						 alert.showAndWait();
	             }
	
		        
	}
	
	
	public static void update_manager_salary(int salary,int user_id) throws ClassNotFoundException, SQLException
	
	
	{
		
		
		Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String updateSQL = "UPDATE Club_Manager SET salary = ? WHERE manager_id = ?";
       
	     PreparedStatement updateStatement = con.prepareStatement(updateSQL);
			
		updateStatement.setInt(1, salary);
		
		updateStatement.setInt(2, user_id);
		     
		int rowsUpdated = updateStatement.executeUpdate();
		     
		        if (rowsUpdated > 0)
		        
		        {
		        	
		        	Alert alert = new Alert(AlertType.INFORMATION);
		        	 
				     alert.setTitle("Success");
				     
				     alert.setHeaderText(null);
				     
				     alert.setContentText("Manager Salary updated successfully.");
				        
				    
					     // Show the alert
					 alert.showAndWait();
					 
					 	
		        }
	
	}
	
	public static void update_player_name(String username,int user_id) throws ClassNotFoundException, SQLException
	
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String updateSQL = "UPDATE user SET username = ? WHERE user_id = ?";
	        
				PreparedStatement updateStatement = con.prepareStatement(updateSQL);
				
				 updateStatement.setString(1, username);
			     updateStatement.setInt(2, user_id);
			     
			     int rowsUpdated = updateStatement.executeUpdate();
			     
			        if (rowsUpdated > 0)
			        
			        {
			        	
			        	Alert alert = new Alert(AlertType.INFORMATION);
			        	 
					     alert.setTitle("Success");
					     
					     alert.setHeaderText(null);
					     
					     alert.setContentText("Player Username updated successfully.");
					        
					     
						     // Show the alert
						 alert.showAndWait();
			        }
			        
			        
	}
	
	
	public static void update_player_password(String password, int user_id) throws ClassNotFoundException, SQLException
	
	{
		
		 Class.forName("com.mysql.cj.jdbc.Driver");
         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
         
         String updateSQL = "UPDATE user SET password = ? WHERE user_id = ?";
	      
				PreparedStatement updateStatement = con.prepareStatement(updateSQL);
				
				 updateStatement.setString(1, password);
			     updateStatement.setInt(2, user_id);
			     
			     int rowsUpdated = updateStatement.executeUpdate();
			     
			        if (rowsUpdated > 0)
			        
			        {
			        	 Alert alert = new Alert(AlertType.INFORMATION);
			        	 
					     alert.setTitle("Success");
					     
					     alert.setHeaderText(null);
					     
					     alert.setContentText("Player Password updated successfully.");
					
						     // Show the alert
						 alert.showAndWait();
			        }
			        
			        
	}
	
	public static void update_player_position(String position,int user_id) throws ClassNotFoundException, SQLException
	
	{
		
		 Class.forName("com.mysql.cj.jdbc.Driver");
         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
         
         String updateSQL = "UPDATE Player SET position = ? WHERE player_id = ?";
         
	       PreparedStatement updateStatement = con.prepareStatement(updateSQL);
				
				 updateStatement.setString(1, position);
			     updateStatement.setInt(2, user_id);
			     
			     int rowsUpdated = updateStatement.executeUpdate();
			     
			        if (rowsUpdated > 0)
			        
			        {
			        	Alert alert = new Alert(AlertType.INFORMATION);
			        	 
					     alert.setTitle("Success");
					     
					     alert.setHeaderText(null);
					     
					     alert.setContentText("Player Position updated successfully.");
					        

						     // Show the alert
						 alert.showAndWait();
			        }
			        
			        
	}
	
	public static void update_player_shirt(String shirt_number,int user_id) throws ClassNotFoundException, SQLException
	
	{
		
		 Class.forName("com.mysql.cj.jdbc.Driver");
         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
         
         String updateSQL = "UPDATE Player SET shirt_number = ? WHERE player_id = ?";
	       
				PreparedStatement updateStatement = con.prepareStatement(updateSQL);
				
				 updateStatement.setString(1, shirt_number);
			     updateStatement.setInt(2, user_id);
			     
			     int rowsUpdated = updateStatement.executeUpdate();
			     
			        if (rowsUpdated > 0)
			        
			        {
			        	
			        	Alert alert = new Alert(AlertType.INFORMATION);
			        	 
					     alert.setTitle("Success");
					     
					     alert.setHeaderText(null);
					     
					     alert.setContentText("Player Shirt Number updated successfully.");
					        
					    

						     // Show the alert
						 alert.showAndWait();
			        }
			        
			        
	}
	
	public static void update_player_csd(Date CSD,int user_id) throws ClassNotFoundException, SQLException
	
	
	{
		
		
		  
	    Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
	    
		String updateSQL = "UPDATE Player SET contract_start_date = ? WHERE player_id = ?";
        
			PreparedStatement updateStatement = con.prepareStatement(updateSQL);
			
			 updateStatement.setDate(1, CSD);
		     updateStatement.setInt(2, user_id);
		     
		     int rowsUpdated = updateStatement.executeUpdate();
		     
		        if (rowsUpdated > 0)
		        
		        {
		        	
		        	Alert alert = new Alert(AlertType.INFORMATION);
		        	 
				     alert.setTitle("Success");
				     
				     alert.setHeaderText(null);
				     
				     alert.setContentText("Player Contract Start Date updated successfully.");
				        
				    
					     // Show the alert
					 alert.showAndWait();
	
		        }
		        
		        
	}
	
	public static void update_player_ced(Date CED,int user_id) throws ClassNotFoundException, SQLException
	
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
	    
	    String updateSQL = "UPDATE Player SET contract_end_date = ? WHERE player_id = ?";
     
			PreparedStatement updateStatement = con.prepareStatement(updateSQL);
			
			 updateStatement.setDate(1, CED);
		     updateStatement.setInt(2, user_id);
		     
		     int rowsUpdated = updateStatement.executeUpdate();
		     
		        if (rowsUpdated > 0)
		        
		        {
		        	Alert alert = new Alert(AlertType.INFORMATION);
		        	 
				     alert.setTitle("Success");
				     
				     alert.setHeaderText(null);
				     
				     alert.setContentText("Player Contract End Date updated successfully.");
				        
				     
					     // Show the alert
					 alert.showAndWait();
					 
					 
		        }
	}
	
	public static void update_staff_username(String username,int user_id) throws ClassNotFoundException, SQLException
	
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String updateSQL = "UPDATE user SET username = ? WHERE user_id = ?";
      
			PreparedStatement updateStatement = con.prepareStatement(updateSQL);
			
			 updateStatement.setString(1, username);
		     updateStatement.setInt(2, user_id);
		     
		     int rowsUpdated = updateStatement.executeUpdate();
		        if (rowsUpdated > 0)
		        
		        {
		        	
		        	  Alert alert = new Alert(AlertType.INFORMATION);
			        	 
					     alert.setTitle("Success");
					     
					     alert.setHeaderText(null);
					     
					     alert.setContentText("Staff Username updated successfully.");
					        
					    
						     // Show the alert
						 alert.showAndWait();
						 
		        }
	}
	
	public static void update_staff_password(String password,int user_id) throws ClassNotFoundException, SQLException
	
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String updateSQL = "UPDATE user SET password = ? WHERE user_id = ?";
     
			PreparedStatement updateStatement = con.prepareStatement(updateSQL);
			
			 updateStatement.setString(1, password);
		     updateStatement.setInt(2, user_id);
		     
		     int rowsUpdated = updateStatement.executeUpdate();
		     
		        if (rowsUpdated > 0)
		        
		        {
		        	  Alert alert = new Alert(AlertType.INFORMATION);
			        	 
					     alert.setTitle("Success");
					     
					     alert.setHeaderText(null);
					     
					     alert.setContentText("Staff Password updated successfully.");
					        
					

						     // Show the alert
						 alert.showAndWait();
						 
		        }
	}
	
	public static void update_staff_salary(int salary,int user_id) throws ClassNotFoundException, SQLException
	
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String updateSQL = "UPDATE Coaching_staff SET salary = ? WHERE staff_id = ?";
      
			PreparedStatement updateStatement = con.prepareStatement(updateSQL);
			
			 updateStatement.setInt(1, salary);
		     updateStatement.setInt(2, user_id);
		     
		     int rowsUpdated = updateStatement.executeUpdate();
		     
		        if (rowsUpdated > 0)
		        
		        {
		        	
		        	Alert alert = new Alert(AlertType.INFORMATION);
		        	 
				     alert.setTitle("Success");
				     
				     alert.setHeaderText(null);
				     
				     alert.setContentText("Staff Member Salary updated successfully.");
				        
				 
					     // Show the alert
					 alert.showAndWait();
					 
		        }
	}
	
	public static void update_fan_name(String username,int user_id) throws SQLException, ClassNotFoundException
	
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String updateSQL = "UPDATE user SET username = ? WHERE user_id = ?";
        
			PreparedStatement updateStatement = con.prepareStatement(updateSQL);
			
			 updateStatement.setString(1, username);
		     updateStatement.setInt(2, user_id);
		     
		     int rowsUpdated = updateStatement.executeUpdate();
		     
		        if (rowsUpdated > 0)
		        
		        {
		        	
		        	  Alert alert = new Alert(AlertType.INFORMATION);
			        	 
					     alert.setTitle("Success");
					     
					     alert.setHeaderText(null);
					     
					     alert.setContentText("Fan Username updated successfully.");
			
						 alert.showAndWait();
	
        
		        }
		        
		        
	}
	
	public static void update_fan_password(String password,int user_id) throws ClassNotFoundException, SQLException
	
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String updateSQL = "UPDATE user SET password = ? WHERE user_id = ?";
       
			PreparedStatement updateStatement = con.prepareStatement(updateSQL);
			
			 updateStatement.setString(1, password);
		     updateStatement.setInt(2, user_id);
		     
		     int rowsUpdated = updateStatement.executeUpdate();
		     
		        if (rowsUpdated > 0)
		        
		        {
		        	  Alert alert = new Alert(AlertType.INFORMATION);
			        	 
					     alert.setTitle("Success");
					     
					     alert.setHeaderText(null);
					     
					     alert.setContentText("Fan Password updated successfully.");
				

						     // Show the alert
						 alert.showAndWait();
						 
		        }
	}
	
	public static void update_fan_balance(int balance,int user_id) throws ClassNotFoundException, SQLException
	
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String updateSQL = "UPDATE Fan SET balance = ? WHERE fan_id = ?";
       
        PreparedStatement updateStatement = con.prepareStatement(updateSQL);
			
			 updateStatement.setInt(1, balance);
		     updateStatement.setInt(2, user_id);
		     
		     int rowsUpdated = updateStatement.executeUpdate();
		     
		        if (rowsUpdated > 0)
		        
		        {
		        	Alert alert = new Alert(AlertType.INFORMATION);
		        	 
				     alert.setTitle("Success");
				     
				     alert.setHeaderText(null);
				     
				     alert.setContentText("Fan Balance updated successfully.");
				        
				
					     // Show the alert
					 alert.showAndWait();
					 
		        }
					 
	}
	
	public boolean delete_user(String username,String password) throws ClassNotFoundException, SQLException
	
	
	{
		
		boolean flag = false;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
	 
        String query = "Delete FROM user WHERE username=? AND password=?";
        
        PreparedStatement pstmt = con.prepareStatement(query);
      
        
        pstmt.setString(1, username);
        pstmt.setString(2, password);
        
        int rowsDeleted = pstmt.executeUpdate();
        
        if (rowsDeleted > 0) 
        
        {
        	
        	Alert alert = new Alert(AlertType.INFORMATION);
       	 
		     alert.setTitle("Success");
		     
		     alert.setHeaderText(null);
		     
		     alert.setContentText("User deleted successfully.");

			 alert.showAndWait();
			 
			 flag = true;
			
        }
        
        else
        	
        {
        	
        	Alert alert = new Alert(AlertType.ERROR);
          	 
		     alert.setTitle("Error");
		     
		     alert.setHeaderText(null);
		     
		     alert.setContentText("No such Username or Password");

			 alert.showAndWait();
			 
        	
        }
        
        return flag;
	}
	
	public static void update_staff_post(String post,int user_id) throws SQLException, ClassNotFoundException
	
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String updateSQL = "UPDATE Coaching_Staff SET post = ? WHERE staff_id = ?";
     
			PreparedStatement updateStatement = con.prepareStatement(updateSQL);
			
			 updateStatement.setString(1, post);
		     updateStatement.setInt(2, user_id);
		     
		     int rowsUpdated = updateStatement.executeUpdate();
		     
		        if (rowsUpdated > 0)
		        
		        {
		        	 Alert alert = new Alert(AlertType.INFORMATION);
		        	 
				     alert.setTitle("Success");
				     
				     alert.setHeaderText(null);
				     
				     alert.setContentText("Staff Member Post updated successfully.");
		
					 alert.showAndWait();
					 
		        }
		        
		        
	}
	
	public String select_season() throws ClassNotFoundException, SQLException
	
	{
		
		String season = null;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String query = "SELECT season FROM player_statistics";
        
        PreparedStatement pstmt = con.prepareStatement(query);
        
        ResultSet resultSet = pstmt.executeQuery();
        
        while (resultSet.next()) 
        
        {
           season = resultSet.getString("season");
            
            
        }
        
        return season;
        
	}
	
	public int get_player_id(Player selected_player) throws ClassNotFoundException, SQLException
	
	
	{
		 int player_id = 0;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String query = "SELECT user_id FROM user WHERE username = ?";
        
        PreparedStatement pstmt = con.prepareStatement(query);
        
        pstmt.setString(1, selected_player.username);
        
        ResultSet player_result = pstmt.executeQuery();
        
        
        
        if (player_result.next()) 
        
        {

           player_id = player_result.getInt("user_id");
        
	    }
        
        
        return player_id;
	}
	
	public PlayerStatistics getPlayerStats(int player_id,String season) throws ClassNotFoundException, SQLException
	
	{
		
		PlayerStatistics player_stats = new PlayerStatistics();
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String stats_query = "select appearances,goals,assists,trophies_won,behavior_records from player_statistics where player_id = ? and season = ? ";
    	
    	try (PreparedStatement playerStatement = con.prepareStatement(stats_query))
    	
    	{
    		
    		playerStatement.setInt(1,player_id); 
    		playerStatement.setString(2,season); 
    		
    		ResultSet resultSet = playerStatement.executeQuery();
    		
    		if(resultSet.next())
    			
    		{
    			
    			player_stats.setAppearances(resultSet.getInt("appearances"));
    			
    			player_stats.setGoals(resultSet.getInt("goals"));
    			
    			player_stats.setAssists(resultSet.getInt("assists"));
    			
    			player_stats.setTrophies(resultSet.getInt("trophies_won"));
    			
    			player_stats.setBehavior_records(resultSet.getString("behavior_records"));
    			
    			
    		}
		
	    }
    	
    	return player_stats;
	}
	
	public void bench_player(int id,String name) throws ClassNotFoundException, SQLException
	
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");

        
        
        String deleteQuery = "Delete from starting_xi where player_id = ?";
        try (PreparedStatement pstmt = con.prepareStatement(deleteQuery)) 
        
        {
        	pstmt.setInt(1,id);

          int rows_updated =  pstmt.executeUpdate();
            
          if(rows_updated > 0)
        	 
         {
            
             Alert alert = new Alert(AlertType.INFORMATION);
        	 
  		     alert.setTitle("Success");
  		     
  		     alert.setHeaderText(null);
  		     
  		     alert.setContentText(name + " is benched for the next match");
  			  
  			 alert.showAndWait();
  			 
         }
          
          else
        	  
          {
        	  
        	  Alert alert = new Alert(AlertType.ERROR);
         	 
   		     alert.setTitle("Error");
   		     
   		     alert.setHeaderText(null);
   		     
   		     alert.setContentText(name + " is already benched for the next match");
   		        
   		    
   			  
   			 alert.showAndWait();
          }
            
      }
	}
	
	public void transfer_player(int id,String name) throws ClassNotFoundException, SQLException
	
	{
		
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String selectQuery1 = "select player_id from transfer_list where player_id = ?";
        
		PreparedStatement pstmt2 = con.prepareStatement(selectQuery1);

	    pstmt2.setInt(1, id);

		ResultSet resultSet = pstmt2.executeQuery();

		if(resultSet.next())
			
		{

			Alert alert = new Alert(AlertType.ERROR);

			alert.setTitle("Error");

			alert.setHeaderText(null);

			alert.setContentText(name + " is already in the transfer list");
			
			alert.showAndWait();

	    }


			else
				
			{
						String insertQuery = "INSERT INTO transfer_list(player_id) VALUES (?)";		

						PreparedStatement pstmt = con.prepareStatement(insertQuery);
				        
						   
						pstmt.setInt(1,id);

						int rows_updated =  pstmt.executeUpdate();

						if(rows_updated > 0)

						{

							Alert alert = new Alert(AlertType.INFORMATION);

							alert.setTitle("Success");

							alert.setHeaderText(null);

							alert.setContentText(name + " is added to a transfer list");
  

							alert.showAndWait();

							
						}
						
						
			}
		
		
		
	}
        
        
									
	
	public int get_latest_match_id() throws ClassNotFoundException, SQLException
	
	{
		int match_id = 0;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String selectQuery = "select match_id from match_ where match_status = 'Upcoming' order by match_id LIMIT 1";
        
         PreparedStatement pstmt = con.prepareStatement(selectQuery);
        
         ResultSet resultSet = pstmt.executeQuery();
 		
 		if(resultSet.next())
 			
 		{
 			
 			match_id = resultSet.getInt("match_id");
 		}

         
        return match_id;
        
	}
	
	
	public void ReviewPlayerStats(int match_id,int id,String name) throws ClassNotFoundException, SQLException
	
	{
		
		boolean flag = checking_starting_xi_count();
		
	    if(flag == true)
	    	
	    {
	    	
	    	boolean flag1 = checking_player_in_starting_xi(id,match_id,name);
	    	
	    	if(flag1 == true)
	    		
	    	{
	    		
	    		
	    		insert_into_starting_xi(id,match_id,name);

				
				    
             }
	    	
	    	
	    }
				
				
	}

	public boolean checking_starting_xi_count() throws ClassNotFoundException, SQLException
	
	{
		
		boolean flag = true;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
		
		String checklimitquery = "select count(player_id) as PlayerCount from starting_xi";
        
        PreparedStatement pstmt = con.prepareStatement(checklimitquery);
        
        ResultSet countResult = pstmt.executeQuery();
        	
       if(countResult.next())
        			
       {
			
			int count = countResult.getInt("PlayerCount");
			
			if(count >= 11)
				
			{
				
				 Alert alert = new Alert(AlertType.ERROR);
           	 
     		     alert.setTitle("Error");
     		     
     		     alert.setHeaderText(null);
     		     
     		     alert.setContentText("There are already 11 players in the Starting XI for the next match");
     		        
  
     			 alert.showAndWait();
     			 
     			 flag = false;
				
			}
			       
		
       }
       
       return flag;
       
	}
	
	public boolean checking_player_in_starting_xi(int id,int match_id,String name) throws ClassNotFoundException, SQLException
	
	{
		boolean flag = true;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
		String selectQuery1 = "select player_id from starting_xi where player_id = ? and match_id = ?";
        
		PreparedStatement pstmt2 = con.prepareStatement(selectQuery1);

		pstmt2.setInt(1, id);
		
		pstmt2.setInt(2, match_id);
    	
		ResultSet resultSet = pstmt2.executeQuery();
	

		if(resultSet.next())

		{

			Alert alert = new Alert(AlertType.ERROR);

			alert.setTitle("Error");

			alert.setHeaderText(null);

			alert.setContentText(name + " is already in the Starting XI for the next match");

			alert.showAndWait();

			flag = false;
	    }

		return flag;
	}
	
	public void insert_into_starting_xi(int id, int match_id,String name) throws ClassNotFoundException, SQLException
	
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
		
        
		String insertQuery = "INSERT INTO starting_xi(match_id, player_id) VALUES (?, ?)";

		PreparedStatement pstmt1 = con.prepareStatement(insertQuery);

      	pstmt1.setInt(1, match_id);
      	
	    pstmt1.setInt(2, id);

			int rows_updated =  pstmt1.executeUpdate();

		    if(rows_updated > 0)

		    {

		    	Alert alert = new Alert(AlertType.INFORMATION);

		        alert.setTitle("Success");

		        alert.setHeaderText(null);

		        alert.setContentText(name + " is inserted into the Starting XI for the next match");

		        
		        alert.showAndWait();

		    }
		    
		    
	}
	
	public int get_club_budget() throws ClassNotFoundException, SQLException
	
	{
		
		int budget = 0;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String query = "SELECT club_budget from club where club_id = ?";
        
        PreparedStatement pstmt = con.prepareStatement(query);
        
        pstmt.setInt(1, 1);
        
        ResultSet resultSet = pstmt.executeQuery();
        
        if (resultSet.next()) 
        
        {
    	   
    	   budget = resultSet.getInt("club_budget");
	    }
	
        return budget;
        
	}
	
	public int get_max_expenditure_id() throws ClassNotFoundException, SQLException
	
	{
		
		int id = 0;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String query = "Select max(expenditure_id) as max_id from Expenditures";
        
        PreparedStatement pstmt = con.prepareStatement(query);
        
        ResultSet id_result = pstmt.executeQuery();
        
        if(id_result.next())
        	
        {
        	
        	id = id_result.getInt("max_id");
        	
        	id+=1;
        	
        	
        }
        
		return id;
        
	}
	
	public void insert_into_expenditures(int max_id, int amount,Date date,String description,Stage current_stage) throws ClassNotFoundException, SQLException, IOException
	
	
	{
		
		

		Class.forName("com.mysql.cj.jdbc.Driver");
		
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String query = "Insert into Expenditures (expenditure_id,amount,description,date) values (?,?,?,?)";
        
        try (PreparedStatement expenditureStatement = con.prepareStatement(query))
		
		{
        
        	expenditureStatement.setInt(1,max_id);
        	
        	expenditureStatement.setInt(2, amount);
        	
        	expenditureStatement.setString(3, description);
        	
        	expenditureStatement.setDate(4, date);
        	
        	expenditureStatement.executeUpdate();
        	
        	Alert alert = new Alert(AlertType.INFORMATION);
	        alert.setTitle("Success");
	        alert.setHeaderText(null);
	        alert.setContentText("Expenditure inserted successfully.");
	 
		    alert.showAndWait();
		    
		    FinanceSystem fs = new FinanceSystem();
		    
		    int reference = 1;
		    
		    fs.RequestTransaction(amount,current_stage,reference);
        	
		}
        
        
	}
	
	public void process_expenditure_transaction(int club_budget) throws ClassNotFoundException, SQLException
	
	{
		
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
        
        String update_query = "Update Club set club_budget = ? where club_id = ?";
        
      
			PreparedStatement updateStatement = con.prepareStatement(update_query);
			
			 updateStatement.setInt(1,club_budget);
		     updateStatement.setInt(2, 1);
		     
		        int rowsUpdated = updateStatement.executeUpdate();
		        if (rowsUpdated > 0)
		        
		        {
		        	
		        	Alert alert = new Alert(AlertType.INFORMATION);
		        	 
				     alert.setTitle("Success");
				     
				     alert.setHeaderText(null);
				     
				     alert.setContentText("Club Budget updated successfully.");

					 alert.showAndWait();

		        }
		        
		        
	}
	
	public void update_expenditure_amount(int amount,int e_id) throws ClassNotFoundException, SQLException
	
	{

		Class.forName("com.mysql.cj.jdbc.Driver");
		
	    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
	    
		  String update_query = "Update Expenditures set amount = ? where expenditure_id = ? ";

			PreparedStatement updateStatement = con.prepareStatement(update_query);
			
			 updateStatement.setInt(1, amount);
		     updateStatement.setInt(2, e_id);
		     
		     int rowsUpdated = updateStatement.executeUpdate();
		     
		        if (rowsUpdated > 0)
		        
		        {
		        	
		        	
		             Alert alert = new Alert(AlertType.INFORMATION);
		        	 
				     alert.setTitle("Success");
				     
				     alert.setHeaderText(null);
				     
				     alert.setContentText("Expenditure Amount updated successfully.");

					 alert.showAndWait();
		        	
		        }
		        
		        
	}
	
	public void update_expenditure_date(int e_id,Date date) throws ClassNotFoundException, SQLException
	
	{
		
		 Class.forName("com.mysql.cj.jdbc.Driver");
			
		    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
		    
		    String update_query = "Update Expenditures set Date = ? where expenditure_id = ?";
		    
		    	PreparedStatement updateStatement = con.prepareStatement(update_query);
				
				 updateStatement.setDate(1, date);
			     updateStatement.setInt(2, e_id);
			     
			     int rowsUpdated = updateStatement.executeUpdate();
			     
			        if (rowsUpdated > 0)
			        
			        {
			        	
			        	Alert alert = new Alert(AlertType.INFORMATION);
			        	 
					     alert.setTitle("Success");
					     
					     alert.setHeaderText(null);
					     
					     alert.setContentText("Expenditure Date updated successfully.");
					        
					  
						 alert.showAndWait();
			        }
			        
	}
	
	public void delete_expenditure(int id, int amount,int reference) throws ClassNotFoundException, SQLException, IOException
	
	
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
		
		String delete_query = "Delete from Expenditures where expenditure_id = ?";
		
		PreparedStatement pstmt = con.prepareStatement(delete_query);

        pstmt.setInt(1, id);
       
        
        int rowsDeleted = pstmt.executeUpdate();
        
        if (rowsDeleted > 0) 
        
        {
        	Alert alert = new Alert(AlertType.INFORMATION);
       	 
		     alert.setTitle("Success");
		     
		     alert.setHeaderText(null);
		     
		     alert.setContentText("Expenditure Deleted successfully.");
		        
			 alert.showAndWait();
        	
        	FinanceSystem fs = new FinanceSystem();
        	
        	fs.request(amount,reference);

        }
		
	}
	
	public boolean check_match_tactics(int match_id) throws ClassNotFoundException, SQLException
	
	{
		
		boolean flag = false;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
		
        String check_query = "Select * from tactics_module where match_id = ?";
        
        PreparedStatement pstmt = con.prepareStatement(check_query);
        
        pstmt.setInt(1,match_id);
       

        // Execute the query
        ResultSet check_result = pstmt.executeQuery();

        if (check_result.next()) 
        
        {
        	flag = true;
        	
        }
        
        
        return flag;
        
	}
	
	public void insert_tactics(int match_id,String formation,String defensive_style,int defensive_width,int defensive_depth,String offensive_style,String chance_creation,int attacking_width) throws ClassNotFoundException, SQLException
	
	{
		
			Class.forName("com.mysql.cj.jdbc.Driver");
		
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
		
		   String insertQuery = "Insert into tactics_module (match_id,formation,defensive_style,defensive_width,defensive_depth,offensive_style,chance_creation,attacking_width) values (?,?,?,?,?,?,?,?)";
	        
	        PreparedStatement tacticsStatement = con.prepareStatement(insertQuery);
		
	        	tacticsStatement.setInt(1, match_id); // Assuming player_id is the same as user_id
	        	tacticsStatement.setString(2, formation); // Replace with your actual text field
	        	tacticsStatement.setString(3,defensive_style); // Replace with your actual text field
	        	tacticsStatement.setInt(4, defensive_width); // Replace with your actual text field
	        	tacticsStatement.setInt(5,defensive_depth); // Replace with your actual text field
	        	tacticsStatement.setString(6,offensive_style);
	        	tacticsStatement.setString(7, chance_creation);
	        	tacticsStatement.setInt(8, attacking_width);
	        	tacticsStatement.executeUpdate();
	                
	        	
	        	Alert alert = new Alert(AlertType.INFORMATION);
		        alert.setTitle("Success");
		        alert.setHeaderText(null);
		        alert.setContentText("Tactics inserted successfully for the next match.");

		        alert.showAndWait();
	}
	
	
	public void update_match_tactics(int match_id,String formation,String defensive_style,int defensive_width,int defensive_depth,String offensive_style,String chance_creation,int attacking_width) throws ClassNotFoundException, SQLException
	
	
	{

		Class.forName("com.mysql.cj.jdbc.Driver");
	
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
		
		String update_query = "Update tactics_module set formation = ?,defensive_style = ?,defensive_width = ?,defensive_depth = ?,offensive_style = ?,chance_creation = ?,attacking_width = ? where match_id = ?";
	    PreparedStatement tacticsStatement = con.prepareStatement(update_query);

	   
    	tacticsStatement.setString(1, formation); // Replace with your actual text field
    	tacticsStatement.setString(2,defensive_style); // Replace with your actual text field
    	tacticsStatement.setInt(3, defensive_width); // Replace with your actual text field
    	tacticsStatement.setInt(4,defensive_depth); // Replace with your actual text field
    	tacticsStatement.setString(5,offensive_style);
    	tacticsStatement.setString(6, chance_creation);
    	tacticsStatement.setInt(7, attacking_width);
    	tacticsStatement.setInt(8, match_id); 
    	tacticsStatement.executeUpdate();
            

    	int rowsUpdated = tacticsStatement.executeUpdate();

    	 if (rowsUpdated > 0)
    	     
         {
         	

         	Alert alert = new Alert(AlertType.INFORMATION);
    	        alert.setTitle("Success");
    	        alert.setHeaderText(null);
    	        alert.setContentText("Tactics inserted successfully for the next match.");

    	        alert.showAndWait();
    	}
         	
    
	}
	
	public int get_fan_balance(int fan_id) throws ClassNotFoundException, SQLException
	
	
	{
		
		int balance = 0;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
	    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
	    
	    String query = "Select balance from fan where fan_id = ?";
	    
	    PreparedStatement pstmt = con.prepareStatement(query);
        pstmt.setInt(1,fan_id);
        
        
        ResultSet balance_result = pstmt.executeQuery();

        if (balance_result.next()) 
        
        {
        	
           balance = balance_result.getInt("balance");
           
	    }
        
        return balance;
    }
	
	public int get_max_item_id(int fan_id) throws ClassNotFoundException, SQLException
	
	{
		
		int max_item_id = 0;
		
		 
		Class.forName("com.mysql.cj.jdbc.Driver");
       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
      
      String query = "SELECT MAX(item_id) as item FROM cart where fan_id = ?";
      PreparedStatement pstmt = con.prepareStatement(query);
      
      pstmt.setInt(1,fan_id);
      
      ResultSet item_result = pstmt.executeQuery();

      if (item_result.next()) 
      
      {
		 
      	max_item_id= item_result.getInt("item");
      	max_item_id+=1;
      	
    
		 
      }
      
      return max_item_id;
      
	}
	
	public int get_individual_item_price(int ticket_id,int merch_id) throws ClassNotFoundException, SQLException
	
	
	{
		
		int price = 0;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
	    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
	    
	    if(ticket_id!=0)
	    	
	    {
	    	
	    	String query = "SELECT price from ticket where ticket_id = ?";
		    
	    	PreparedStatement cartStatement = con.prepareStatement(query);
		
	    	cartStatement.setInt(1,ticket_id);
	    	
	    	ResultSet resultSet = cartStatement.executeQuery();
	  
	    	if(resultSet.next())
    			
    		{
    			
    		    price = resultSet.getInt("price");
    			
    		
    		}	
	   
	    }
	    
	    else if(merch_id!=0)
	    	
	    {
	    	
	    	String query = "SELECT price from merchandise where merch_id = ?";
		    
	    	PreparedStatement cartStatement = con.prepareStatement(query);
		

			cartStatement.setInt(1,merch_id);
	
			ResultSet resultSet = cartStatement.executeQuery();
	
			if(resultSet.next())
    			
			{
	
			  price = resultSet.getInt("price");
			  
			}
			
	    }
		
	    
		return price;
	}				  
	    					  
	 
	
	public int get_total_price_of_cart(int p) throws ClassNotFoundException, SQLException
	
	{
		
		int item_price = p;
		
		System.out.print(item_price);
		
		int total_price = 0;
		
		//System.out.print(t_price);
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
		
		 String query1 = "SELECT Max(total_price) as hello FROM cart where fan_id = ?";
		 
	        PreparedStatement pstmt1 = con.prepareStatement(query1);
	        
	       // System.out.print(this.fan_id);
	        
	        pstmt1.setInt(1,display_ticket_scheduleController.fan_id);
	        
	        ResultSet price_result = pstmt1.executeQuery();

	        if (price_result.next()) 
	        
	        {
			 
	        	
	            total_price = price_result.getInt("hello");
	        	
	        	total_price += item_price;
	        	
	        	
	        }
			
	        
	        return total_price;
	}
	
	
	public void insert_item_into_cart(int max_item_id,int ticket_id,int merch_id,int fan_id,int total_price) throws ClassNotFoundException, SQLException
	
	
	{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
		
		String query2 = "Insert into cart (item_id,ticket_id,merch_id,fan_id,total_price) values (?,?,?,?,?)";
    	
        PreparedStatement cart_result = con.prepareStatement(query2);
		
    		cart_result.setInt(1, max_item_id);
    		
    		cart_result.setInt(2,ticket_id);
    		
    		cart_result.setInt(3,merch_id);
    		
    		cart_result.setInt(4, fan_id);
    		
    		cart_result.setInt(5,total_price);
    		
    		cart_result.executeUpdate();
    		
    		Alert alert = new Alert(AlertType.INFORMATION);
	        alert.setTitle("Success");
	        alert.setHeaderText(null);
	        alert.setContentText("Item added into cart successfully.");
    		alert.showAndWait();
	}
	
	
	
	public int get_checkout_price(int fan_id) throws ClassNotFoundException, SQLException
	
	
	{
		
		int total_price = 0;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
	    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
	    
	    String query = "SELECT max(total_price) as max_price FROM cart WHERE fan_id = ?";
	    
	    PreparedStatement cartStatement = con.prepareStatement(query);

	    	
	    	cartStatement.setInt(1,fan_id);
	    	
	    	ResultSet resultSet = cartStatement.executeQuery();
			 
			if(resultSet.next())
				
			{
				
				 total_price = resultSet.getInt("max_price");
				
			
			}
			
			
			return total_price;
			
	}
	
	public void update_fan_balance(int fan_id,int balance,int total_price) throws ClassNotFoundException, SQLException
	
	{
		

    	// System.out.print(total_price);
		
		if(total_price != 0)
			
		{
	
			Class.forName("com.mysql.cj.jdbc.Driver");
		
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
 
			balance = balance - total_price;
    		
	    
			String query1 = "Update fan Set balance = ? where fan_id = ?";
    		
    	
    			PreparedStatement updateStatement = con.prepareStatement(query1);
    			
    			 updateStatement.setInt(1, balance);
    		     updateStatement.setInt(2, fan_id);
    		     
    		     int rowsUpdated = updateStatement.executeUpdate();
    		     
    		        if (rowsUpdated > 0)
    		        
    		        {
    		        	
    		         Alert alert = new Alert(AlertType.INFORMATION);
   		        	 
   				     alert.setTitle("Success");
   				     
   				     alert.setHeaderText(null);
   				     
   				     alert.setContentText("Fan Balance updated successfully.");
   				       

   					     // Show the alert
   					 alert.showAndWait();
   					 
   					
    		        	
    		        }
    		        
		}
		
		
	}
	
	public String get_item_description(int ticket_id,int merch_id) throws ClassNotFoundException, SQLException
	
	
	{
		
		
		String description = null;

		Class.forName("com.mysql.cj.jdbc.Driver");
		
	    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
	    
	    if(ticket_id!=0)
	    	
	 {
	    
	    	String query = "SELECT ticket_description from ticket where ticket_id = ?";
	    
	    	PreparedStatement cartStatement = con.prepareStatement(query);
		
	    	cartStatement.setInt(1,ticket_id);
	    	
			ResultSet resultSet = cartStatement.executeQuery();

		    {
	
		    		if(resultSet.next())
		
		    		{
		
		    				 description = resultSet.getString("ticket_description");
		
		    				
		    		}

		    }
	   
	    			
         }
	    
	    else if(merch_id!=0)
	    	
	    {
	    	
	    	String query = "SELECT merch_description from merchandise where merch_id = ?";
		    
	    	PreparedStatement cartStatement = con.prepareStatement(query);
		

			cartStatement.setInt(1,merch_id);

		   ResultSet resultSet = cartStatement.executeQuery();

		    		if(resultSet.next())
		
		    		{
		
		    			    description = resultSet.getString("merch_description");
		
		    		}
 		
	    }
	    
	    
		return description;
	}
	
	public void confirm_purchase(int fan_id) throws ClassNotFoundException, SQLException, IOException
	
	
	{
		
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
	    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda_project", "root", "PHW#84#jeor");
  
	    String query = "Delete FROM cart WHERE fan_id = ?";
        
        PreparedStatement pstmt = con.prepareStatement(query);
      
        
        pstmt.setInt(1, fan_id);

        
        int rowsDeleted = pstmt.executeUpdate();
        
        if (rowsDeleted > 0) 
        
        {
		
			 Alert alert = new Alert(AlertType.INFORMATION);
    	 
		     alert.setTitle("Success");
		     
		     alert.setHeaderText(null);
		     
		     alert.setContentText("Purchase Confirmed");
	

			     // Show the alert
			 alert.showAndWait();
			 
			
	     }
        
        
        else
        	
        {
        	
        	 Alert alert = new Alert(AlertType.ERROR);
        	 
		     alert.setTitle("Error");
		     
		     alert.setHeaderText(null);
		     
		     alert.setContentText("You have no items in your cart");

			     // Show the alert
			 alert.showAndWait();
			 
			 
        	
        }
        
        
	}
}