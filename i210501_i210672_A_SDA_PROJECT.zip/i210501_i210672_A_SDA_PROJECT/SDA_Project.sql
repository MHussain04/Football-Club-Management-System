create database sda_project

use sda_project

create table admin

(

admin_id int primary key,username VARCHAR(30),password VARCHAR(30), Role Varchar(30)

)


create table user

(

user_id int primary key,username VARCHAR(30),password VARCHAR(30), Role VARCHAR(30)

)

select * from user

CREATE TABLE Club_Manager (
    manager_id int,
    salary int,
    FOREIGN KEY (manager_id) REFERENCES user(user_id) ON UPDATE CASCADE ON DELETE CASCADE
)

create table Coaching_Staff (
staff_id int, 
Post varchar(30), 
salary int, 
FOREIGN KEY (staff_id) REFERENCES user(user_id) ON UPDATE CASCADE ON DELETE CASCADE
)

create table Player

(

player_id int,
position varchar(30),
dob date,
shirt_number varchar(30),
contract_start_date Date,
contract_end_date Date,
FOREIGN KEY (player_id) REFERENCES user(user_id) ON UPDATE CASCADE ON DELETE CASCADE

)

create table fan

(

fan_id int,

balance int,

foreign key (fan_id) references user(user_id) on update cascade on delete cascade

)

create table match_

(

match_id int primary key,

vs varchar(100),

match_date Date,

location varchar(50),

result varchar(50),

match_status varchar(50)

)

Insert into match_ values

(1,'Chelsea','2023-11-12','Stamford Bridge','4-4','Past')

Insert into match_ values

(2,'Liverpool','2023-11-26','Eithad','1-1','Past')

Insert into match_ values

(3,'Tottenham','2023-12-3','Eithad',null,'Upcoming')

Insert into match_ values
(4,'Manchester United','2023-12-8','Eithad',null,'Upcoming')


create table player_statistics

(player_id int, appearances int, goals int, assists int, trophies_won int, season varchar(50), behavior_records varchar(50), foreign key(player_id) references Player(player_id) on update cascade on delete cascade)

insert into player_statistics values
(11,12,6,4,1,'2023-2024','Excellent')

CREATE TABLE starting_xi (
    match_id INT,
    player_id INT,
    FOREIGN KEY (match_id) REFERENCES match_(match_id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (player_id) REFERENCES Player(player_id) ON UPDATE CASCADE ON DELETE CASCADE
);

create table transfer_list

(player_id int,

foreign key(player_id) references Player(player_id) on update cascade on delete cascade)


create table ticket

(

ticket_id int primary key,

ticket_description varchar(300),

price int

)

create table merchandise

(

merch_id int primary key,

merch_description varchar(100),

price int

)



insert into merchandise values

(

4,'Manchester City GoalKeeper Jersey 23/24',20000

)

create table cart

(

item_id int,

ticket_id int,

merch_id int,

fan_id int,

total_price int,

foreign key(fan_id) references fan(fan_id) on update cascade on delete cascade,

foreign key(ticket_id) references ticket(ticket_id) on update cascade on delete cascade,

foreign key(merch_id) references merchandise(merch_id) on update cascade on delete cascade



)


insert into ticket values

(0,'NULL',0)




create table club

(

club_id int primary key,

club_name varchar(50),

club_budget int

)


Insert into club values

(1,'Manchester City',17500000)


Create table Expenditures

(

expenditure_id int,

amount int,

description varchar(50),

Date date

)


create table tactics_module

(

match_id int,

formation varchar(50) not null,

defensive_style varchar(100) not null,

defensive_width int,

defensive_depth int,

offensive_style varchar(100) not null,

chance_creation varchar(50) not null,

attacking_width int,

foreign key(match_id) references match_(match_id) on update cascade on delete cascade

)


